package fr.uge.manifest;

public interface ItemManifest {
	public abstract int price();
	public abstract String toString();
	public abstract String getDestination();
	public abstract String getId();
	
}
